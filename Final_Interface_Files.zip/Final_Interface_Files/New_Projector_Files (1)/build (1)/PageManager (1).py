from tkinter import Tk

from mainMenu import MainMenu
from projectorInputs import ProjectorInputs
from projectorSettings import ProjectorSettings
from animateBackdrop import AnimateBackdrop
from favoriteApps import FavoriteApps

page_class_map = {
    "PAGE_MAIN_MENU": MainMenu,
    "PAGE_PROJECTOR_INPUTS": ProjectorInputs,
    "PAGE_PROJECTOR_SETTINGS": ProjectorSettings,
    "PAGE_ANIMATE_BACKDROP": AnimateBackdrop,
    "PAGE_FAVORITE_APPS": FavoriteApps
}


class PageManager(Tk):
    def __init__(self, *args, **kwargs):
        Tk.__init__(self, *args, **kwargs)

        self.pages = {}
        for page_class_str in page_class_map.keys():
            page_class_type = page_class_map[page_class_str]
            self.pages[page_class_str] = page_class_type

        self.state = {}

        self.show_page("PAGE_MAIN_MENU")

    def show_page(self, page_class_str):
        page_instance = self.pages[page_class_str](self)
        # page_instance.grid(row=0, column=0, sticky="nsew")
        # page_instance.tkraise()

    def redirect_page(self, page_class_str: str):
        self.show_page(page_class_str)




if __name__ == "__main__":
    app = PageManager()
    app.mainloop()

