import serial

# set up the serial connection
ser = serial.Serial('/dev/tty.usbserial-FTD2M057', 9600, timeout=1)

# send a command to turn the projector on
ser.write(b'\x02ADZZ;OMN\x03')

# read the response from the projector
response = ser.readline()
print(response)

# close the serial connection
ser.close()
