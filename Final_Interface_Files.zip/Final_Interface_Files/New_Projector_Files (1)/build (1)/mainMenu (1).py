from pathlib import Path
import serial 
import time 
from tkinter import Canvas, Button, PhotoImage, Frame

OUTPUT_PATH = Path(__file__).parent
ASSETS_PATH = OUTPUT_PATH / Path(r"/home/cms/Documents/Projector_Files/New_Projector_Files/build/assets/mainMenu")
# set up the serial connection
ser = serial.Serial('/dev/ttyUSB0', 9600)

def relative_to_assets(path: str) -> Path:
    return ASSETS_PATH / Path(path)

class MainMenu(Frame):
    def __init__(self, master, *args, **kwargs):
        Frame.__init__(self, master, *args, **kwargs)
        master.geometry("1023x604")
        master.configure(bg = "#F2F2EB")
        master.resizable(False, False)

        canvas = Canvas(
        master,
        bg = "#F2F2EB",
        height = 604,
        width = 1023,
        bd = 0,
        highlightthickness = 0,
        relief = "ridge"
        )

        canvas.place(x = 0, y = 0)
        image_image_1 = PhotoImage(
            file=relative_to_assets("image_1.png"))
        image_1 = canvas.create_image(
            844.0,
            318.0,
            image=image_image_1
        )

        image_image_2 = PhotoImage(
            file=relative_to_assets("image_2.png"))
        image_2 = canvas.create_image(
            844.0,
            107.0,
            image=image_image_2
        )

        button_image_1 = PhotoImage(
            file=relative_to_assets("button_1.png"))
        button_1 = Button(
            image=button_image_1,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: (master.redirect_page("PAGE_PROJECTOR_SETTINGS")),
            relief="flat"
        )
        button_1.place(
            x=18.0,
            y=322.0,
            width=326.1391296386719,
            height=234.0
        )

        button_image_2 = PhotoImage(
            file=relative_to_assets("button_2.png"))
        button_2 = Button(
            image=button_image_2,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: (master.redirect_page("PAGE_PROJECTOR_INPUTS")),
            relief="flat"
        )
        button_2.place(
            x=18.0,
            y=80.0,
            width=329.0,
            height=234.0
        )

        button_image_3 = PhotoImage(
            file=relative_to_assets("button_3.png"))
        button_3 = Button(
            image=button_image_3,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: (master.redirect_page("PAGE_ANIMATE_BACKDROP")),
            relief="flat"
        )
        button_3.place(
            x=357.0,
            y=322.0,
            width=329.0,
            height=234.0
        )

        image_image_3 = PhotoImage(
            file=relative_to_assets("image_3.png"))
        image_3 = canvas.create_image(
            778.3671264648438,
            228.9330596923828,
            image=image_image_3
        )

        image_image_4 = PhotoImage(
            file=relative_to_assets("image_4.png"))
        image_4 = canvas.create_image(
            908.69775390625,
            228.9330596923828,
            image=image_image_4
        )
        #start of Volume + button  

        def VolumeUp(): 
            ser.write(b'\x02ADZZ;AUU\x03')

        button_image_4 = PhotoImage(
            file=relative_to_assets("button_4.png"))
        button_4 = Button(
            image=button_image_4,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: VolumeUp(),
            relief="flat"
        )
        
        button_4.place(
            x=871.6754760742188,
            y=212.23326110839844,
            width=75.1541748046875,
            height=37.10142135620117
        )
        #end of Volume + button 
        #Start of Power Off
        def PowerOff(): 
            ser.write(b'\x02ADZZ;POF\x03')
            # Send the query
            ser.write(b'\x02QPW\x03')
            time.sleep(0.5) 
            # Wait for the response
            response = ser.read_until(b'\x03')
            # Update the button image based on the response
            if b'POF' in response:
                button_image_5.config(file=relative_to_assets("button_17.png"))
                button_image_6.config(file=relative_to_assets("button_6.png"))
                master.state["mainMenuPowerOn"] = False
                master.state["mainMenuPowerOff"] = True 
                
            else:
                button_image_5.config(file=relative_to_assets("button_5.png"))
                master.state["mainMenuPowerOff"] = False  

        PowerOff1Filename = "button_17.png" if master.state.get("mainMenuPowerOff") else "button_5.png"

        button_image_5 = PhotoImage(
            file=relative_to_assets(PowerOff1Filename))
        button_5 = Button(
            image=button_image_5,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: PowerOff(),
            relief="flat"
        )
        button_5.place(
            x=742.0,
            y=263.0,
            width=75.1541748046875,
            height=37.10142135620117
        )
        #End of Power Off 
        #Start of Power On 
        def PowerOn():
             # Send the power-on command
            ser.write(b'\x02ADZZ;PON\x03')
            # Send the query
            ser.write(b'\x02QPW\x03')
            time.sleep(0.5) 
            # Wait for the response
            response = ser.read_until(b'\x03')
            # Update the button image based on the response
            if b'PON' in response:
                button_image_6.config(file=relative_to_assets("button_16.png"))
                button_image_5.config(file=relative_to_assets("button_5.png"))
                master.state["mainMenuPowerOn"] = True
                master.state["mainMenuPowerOff"] = False
            else:
                button_image_6.config(file=relative_to_assets("button_6.png"))
                master.state["mainMenuPowerOn"] = False 
        
        PowerOn1Filename = "button_16.png" if master.state.get("mainMenuPowerOn") else "button_6.png"
        
        button_image_6 = PhotoImage(
            file=relative_to_assets(PowerOn1Filename))
        button_6 = Button(
            image=button_image_6,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: PowerOn(),
            relief="flat"
        )
        button_6.place(
            x=741.0,
            y=212.0,
            width=75.1541748046875,
            height=37.10142135620117
        )
        #End if Power On 
        #Start of Volume - button 
        def VolumeDown(): 
            ser.write(b'\x02ADZZ;AUD\x03')

        button_image_7 = PhotoImage(
            file=relative_to_assets("button_7.png"))
        button_7 = Button(
            image=button_image_7,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: VolumeDown(),
            relief="flat"
        )
        button_7.place(
            x=872.0,
            y=262.0,
            width=75.1541748046875,
            height=37.10142135620117
        )
        #End of Volume - button 

        canvas.create_rectangle(
            0.0,
            0.0,
            1023.0,
            67.0,
            fill="#D9D9D9",
            outline="")

        #Start of Menu Button 
        def MenuButton(): 
            ser.write(b'\x02ADZZ;OMN\x03')

        button_image_8 = PhotoImage(
            file=relative_to_assets("button_8.png"))
        button_8 = Button(
            image=button_image_8,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: MenuButton(),
            relief="flat"
        )
        button_8.place(
            x=721.0,
            y=335.0,
            width=88.47259521484375,
            height=48.517242431640625
        )
        #End of Menu Button 

        #Start of Return Button 
        def ReturnButton(): 
            ser.write(b'\x02ADZZ;OBK\x03')

        button_image_9 = PhotoImage(
            file=relative_to_assets("button_9.png"))
        button_9 = Button(
            image=button_image_9,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: ReturnButton(),
            relief="flat"
        )
        button_9.place(
            x=879.0,
            y=335.0,
            width=88.47259521484375,
            height=48.517242431640625
        )
        #End of Return Button 

        #Start of down arrow 
        def DownArrow(): 
            ser.write(b'\x02ADZZ;OCD\x03')
        button_image_10 = PhotoImage(
            file=relative_to_assets("button_10.png"))
        button_10 = Button(
            image=button_image_10,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: DownArrow(),
            relief="flat"
        )
        button_10.place(
            x=820.5404663085938,
            y=490.32470703125,
            width=48.0447998046875,
            height=46.36878967285156
        )
        #End of down arrow 

        #Start of Right arrow 
        def RightArrow(): 
            ser.write(b'\x02ADZZ;OCR\x03')
        button_image_11 = PhotoImage(
            file=relative_to_assets("button_11.png"))
        button_11 = Button(
            image=button_image_11,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: RightArrow(),
            relief="flat"
        )
        button_11.place(
            x=879.7584838867188,
            y=432.2240295410156,
            width=48.0447998046875,
            height=46.36878967285156
        )
        #End of Right Arrow 

        image_image_5 = PhotoImage(
            file=relative_to_assets("image_5.png"))
        image_5 = canvas.create_image(
            510.0,
            34.0,
            image=image_image_5
        )

        button_image_12 = PhotoImage(
            file=relative_to_assets("button_12.png"))
        button_12 = Button(
            image=button_image_12,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: master.redirect_page("PAGE_FAVORITE_APPS"),
            relief="flat"
        )
        button_12.place(
            x=357.0,
            y=80.0,
            width=329.0,
            height=234.0
        )
        #Start of Enter Button 
        def EnterButton(): 
            ser.write(b'\x02ADZZ;OEN\x03')

        button_image_13 = PhotoImage(
            file=relative_to_assets("button_13.png"))
        button_13 = Button(
            image=button_image_13,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: EnterButton(),
            relief="flat"
        )
        button_13.place(
            x=820.5404663085938,
            y=432.2240295410156,
            width=48.0447998046875,
            height=46.36878967285156
        )
        #End of Enter button 

        #Start of left Arrow 
        def LeftArrow(): 
            ser.write(b'\x02ADZZ;OCL\x03')

        button_image_14 = PhotoImage(
            file=relative_to_assets("button_14.png"))
        button_14 = Button(
            image=button_image_14,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: LeftArrow(),
            relief="flat"
        )
        button_14.place(
            x=761.322509765625,
            y=432.2240295410156,
            width=48.0447998046875,
            height=46.36878967285156
        )
        #End of Left Arrow 

        #Start of Up arrow button 
        def UpArrow(): 
            ser.write(b'\x02ADZZ;OCU\x03')

        button_image_15 = PhotoImage(
            file=relative_to_assets("button_15.png"))
        button_15 = Button(
            image=button_image_15,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: UpArrow(),
            relief="flat"
        )
        button_15.place(
            x=820.5404663085938,
            y=373.0060729980469,
            width=48.0447998046875,
            height=46.36878967285156
        )
        #End of Up arrow button 

        image_image_6 = PhotoImage(
            file=relative_to_assets("image_6.png"))
        image_6 = canvas.create_image(
            910.0,
            172.0,
            image=image_image_6
        )

        canvas.create_rectangle(
            731.0,
            257.0,
            828.0,
            257.0,
            fill="#FFFFFF",
            outline="")

        canvas.create_rectangle(
            862.0,
            257.0,
            959.0,
            257.0,
            fill="#FFFFFF",
            outline="")
                    
        master.mainloop()
