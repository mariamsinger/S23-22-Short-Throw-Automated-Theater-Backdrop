from pathlib import Path
import serial 
import time 
from tkinter import Canvas, Button, PhotoImage, Frame

OUTPUT_PATH = Path(__file__).parent
ASSETS_PATH = OUTPUT_PATH / Path(r"/home/cms/Documents/Projector_Files/New_Projector_Files/build/assets/projSettings")
ser = serial.Serial('/dev/ttyUSB0', 9600)

def relative_to_assets(path: str) -> Path:
    return ASSETS_PATH / Path(path)

class ProjectorSettings(Frame):
    def __init__(self, master):
        Frame.__init__(self, master)
        master.geometry("1023x604")
        master.configure(bg = "#F2F2EB")
        master.resizable(False, False)

        canvas = Canvas(
        master,
        bg = "#F2F2EB",
        height = 604,
        width = 1023,
        bd = 0,
        highlightthickness = 0,
        relief = "ridge"
    )

        canvas.place(x = 0, y = 0)
        image_image_1 = PhotoImage(
            file=relative_to_assets("image_1.png"))
        image_1 = canvas.create_image(
            513.0,
            310.0,
            image=image_image_1
        )

        button_image_1 = PhotoImage(
            file=relative_to_assets("button_1.png"))
        button_1 = Button(
            image=button_image_1,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: master.redirect_page("PAGE_MAIN_MENU"),
            relief="flat"
        )
        button_1.place(
            x=859.0,
            y=481.0,
            width=117.0,
            height=42.75
        )

        #start of Menu 
        def MenuButton(): 
            ser.write(b'\x02ADZZ;OMN\x03')
        button_image_2 = PhotoImage(
            file=relative_to_assets("button_2.png"))
        button_2 = Button(
            image=button_image_2,
            borderwidth=0,
            highlightthickness=0,
            command=lambda:MenuButton(),
            relief="flat"
        )
        button_2.place(
            x=450.0,
            y=93.0,
            width=123.0,
            height=99.0
        )
        #End of Menu 

        #Start of Return 
        def ReturnButton(): 
            ser.write(b'\x02ADZZ;OBK\x03')
  
        button_image_3 = PhotoImage(
            file=relative_to_assets("button_3.png"))
        button_3 = Button(
            image=button_image_3,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: ReturnButton(),
            relief="flat"
        )
        button_3.place(
            x=449.0,
            y=427.0,
            width=123.0,
            height=99.0
        )
        #End of Return 

        #Start of Enter button 
        def EnterButton(): 
            ser.write(b'\x02ADZZ;OEN\x03')

        button_image_4 = PhotoImage(
            file=relative_to_assets("button_4.png"))
        button_4 = Button(
            image=button_image_4,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: EnterButton(),
            relief="flat"
        )
        button_4.place(
            x=729.1879272460938,
            y=251.1878662109375,
            width=105.6241455078125,
            height=101.9395751953125
        )
        #End of Enter Button 

        #Start of down arrow 
        def DownArrow(): 
            ser.write(b'\x02ADZZ;OCD\x03')

        button_image_5 = PhotoImage(
            file=relative_to_assets("button_5.png"))
        button_5 = Button(
            image=button_image_5,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: DownArrow(),
            relief="flat"
        )
        button_5.place(
            x=729.1879272460938,
            y=378.91943359375,
            width=105.6241455078125,
            height=101.939697265625
        )
        #End of down arrow 
        #Start of Up button 
        def UpArrow(): 
            ser.write(b'\x02ADZZ;OCU\x03')
        button_image_6 = PhotoImage(
            file=relative_to_assets("button_6.png"))
        button_6 = Button(
            image=button_image_6,
            borderwidth=0,
            highlightthickness=0,
            command=lambda:UpArrow(),
            relief="flat"
        )
        button_6.place(
            x=729.1879272460938,
            y=121.0,
            width=105.6241455078125,
            height=101.9395751953125
        )
        #end if Up button 

        #Start of Right Button 
        def RightArrow(): 
            ser.write(b'\x02ADZZ;OCR\x03')
         
        button_image_7 = PhotoImage(
            file=relative_to_assets("button_7.png"))
        button_7 = Button(
            image=button_image_7,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: RightArrow(),
            relief="flat"
        )
        button_7.place(
            x=859.3758544921875,
            y=251.1878662109375,
            width=105.6241455078125,
            height=101.9395751953125
        )
        #End of Right Button 

        #Start of left arrow 
        def LeftArrow(): 
            ser.write(b'\x02ADZZ;OCL\x03')
    
        button_image_8 = PhotoImage(
            file=relative_to_assets("button_8.png"))
        button_8 = Button(
            image=button_image_8,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: LeftArrow(),
            relief="flat"
        )
        button_8.place(
            x=599.0,
            y=251.1878662109375,
            width=105.62417602539062,
            height=101.9395751953125
        )
        #End of left arrow 
        

        image_image_2 = PhotoImage(
            file=relative_to_assets("image_2.png"))
        image_2 = canvas.create_image(
            511.0,
            36.0,
            image=image_image_2
        )

        image_image_3 = PhotoImage(
            file=relative_to_assets("image_3.png"))
        image_3 = canvas.create_image(
            115.0,
            197.0,
            image=image_image_3
        )

        image_image_4 = PhotoImage(
            file=relative_to_assets("image_4.png"))
        image_4 = canvas.create_image(
            376.0,
            421.0,
            image=image_image_4
        )

        image_image_5 = PhotoImage(
            file=relative_to_assets("image_5.png"))
        image_5 = canvas.create_image(
            245.0,
            421.0,
            image=image_image_5
        )

        image_image_6 = PhotoImage(
            file=relative_to_assets("image_6.png"))
        image_6 = canvas.create_image(
            115.0,
            421.0,
            image=image_image_6
        )

        image_image_7 = PhotoImage(
            file=relative_to_assets("image_7.png"))
        image_7 = canvas.create_image(
            245.0,
            197.0,
            image=image_image_7
        )
       
        


    #Audio Video Mute Start 
    ######################
        def AVOff():
            # Send the AV Off command
            ser.write(b'\x02ADZZ;OSH:0\x03')
            # Send the QSH query
            ser.write(b'\x02QSH\x03')
            time.sleep(0.5) 
            # Wait for the response
            response = ser.read_until(b'\x03')
            # Update the button image based on the response
            if b'0' in response:
                button_image_11.config(file=relative_to_assets("button_24.png"))
                button_image_18.config(file=relative_to_assets("button_18.png"))

                master.state["projectorSettingsAVOn"] = False
                master.state["projectorSettingsAVOff"] = True
            else:
                button_image_11.config(file=relative_to_assets("button_11.png"))
                master.state["projectorSettingsAVOff"] = False 

        AVOffFilename = "button_24.png" if master.state.get("projectorSettingsAVOff") else "button_11.png"

        button_image_11 = PhotoImage(
        file=relative_to_assets(AVOffFilename))
        button_11 = Button(
            image=button_image_11,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: AVOff(),
            relief="flat"
        )
        button_11.place(
            x=74.0,
            y=450.0,
            width=82.0,
            height=52.0
        )

        def AVOn(): 
            # Send the AV On command
            ser.write(b'\x02ADZZ;OSH:1\x03')
            # Send the QSH query
            ser.write(b'\x02QSH\x03')
            time.sleep(0.5) 
            # Wait for the response
            response = ser.read_until(b'\x03')
            # Update the button image based on the response
            if b'1' in response:
                button_image_18.config(file=relative_to_assets("button_23.png"))
                button_image_11.config(file=relative_to_assets("button_11.png"))

                master.state["projectorSettingsAVOn"] = True 
                master.state["projectorSettingsAVOff"] = False 
            else:
                button_image_18.config(file=relative_to_assets("button_18.png"))
                master.state["projectorSettingsAVOn"] = False 
        
        AVOnFilename = "button_23.png" if master.state.get("projectorSettingsAVOn") else "button_18.png"   
        button_image_18 = PhotoImage(
            file=relative_to_assets(AVOnFilename))
        button_18 = Button(
            image=button_image_18,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: AVOn(),
            relief="flat"
        )
        button_18.place(
            x=74.0,
            y=365.0,
            width=82.0,
            height=52.0
        )
    

    #Audio Video Mute End
    ######################

     #Freeze Start 
    ######################

        #Start Freeze On 
        def FreezeOn(): 
            ser.write(b'\x02ADZZ;OFZ:1\x03')
            # Send the query
            ser.write(b'\x02QFZ\x03')
            time.sleep(0.5) 
            # Wait for the response
            response = ser.read_until(b'\x03')
            # Update the button image based on the response
            if b'1' in response:
                button_image_12.config(file=relative_to_assets("button_23.png"))
                button_image_9.config(file=relative_to_assets("button_11.png"))

                master.state["projectorSettingsFreezeOn"] = True
                master.state["projectorSettingsFreezeOff"] = False
            else:
                button_image_12.config(file=relative_to_assets("button_12.png"))
                master.state["projectorSettingsFreezeOn"] = False

        FreezeOnFilename = "button_23.png" if master.state.get("projectorSettingsFreezeOn") else "button_12.png"

        button_image_12 = PhotoImage(
            file=relative_to_assets(FreezeOnFilename))
        button_12 = Button(
            image=button_image_12,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: FreezeOn(),
            relief="flat"
        )
        button_12.place(
            x=335.0,
            y=365.0,
            width=82.0,
            height=52.0
        )

     #Start of Freeze Off 
        def FreezeOff(): 
            ser.write(b'\x02ADZZ;OFZ:0\x03')
            # Send the query
            ser.write(b'\x02QSH\x03') 
            time.sleep(0.5) 
            # Wait for the response
            response = ser.read_until(b'\x03')
            # Update the button image based on the response
            if b'0' in response:
                button_image_9.config(file=relative_to_assets("button_24.png"))
                button_image_12.config(file=relative_to_assets("button_18.png"))

                master.state["projectorSettingsFreezeOn"] = False
                master.state["projectorSettingsFreezeOff"] = True
            else:
                button_image_9.config(file=relative_to_assets("button_9.png"))
                master.state["projectorSettingsFreezeOff"] = False 

        FreezeOffFilename = "button_24.png" if master.state.get("projectorSettingsFreezeOff") else "button_9.png"

        button_image_9 = PhotoImage(
            file=relative_to_assets(FreezeOffFilename))
        button_9 = Button(
            image=button_image_9,
            borderwidth=0,
            highlightthickness=0,
            command=lambda:FreezeOff(),
            relief="flat"
        )
        button_9.place(
            x=335.0,
            y=450.0,
            width=82.0,
            height=52.0
        )
        #End of freeze Off 

    #Freeze End 
    ######################

        image_image_8 = PhotoImage(
            file=relative_to_assets("image_8.png"))
        image_8 = canvas.create_image(
            376.0,
            197.0,
            image=image_image_8
        )

        image_image_9 = PhotoImage(
            file=relative_to_assets("image_9.png"))
        image_9 = canvas.create_image(
            511.0,
            313.0,
            image=image_image_9
        )

    
     #Autosetup Start
    ######################

        #start of auto setup ON
        def AutoSetupOn(): 
            ser.write(b'\x02ADZZ;OAS\x03')
            # Send the query
            ser.write(b'\x02QAS\x03')
            time.sleep(0.5) 
            # Wait for the response
            response = ser.read_until(b'\x03')
            # Update the button image based on the response
            if b'1' in response:
                button_image_15.config(file=relative_to_assets("button_23.png"))
                button_image_13.config(file=relative_to_assets("button_11.png"))
                master.state["projectorSettingsAutoSetupOn"] = True 
                master.state["projectorSettingsAutoSetupOff"] = False
            else:
                button_image_15.config(file=relative_to_assets("button_12.png"))
                master.state["projectorSettingsAutoSetupOn"] = False

        AutoSetupOnFilename = "button_23.png" if master.state.get("projectorSettingsAutoSetupOn") else "button_12.png"

        button_image_15 = PhotoImage(
            file=relative_to_assets(AutoSetupOnFilename))
        button_15 = Button(
            image=button_image_15,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: AutoSetupOn(),
            relief="flat"
        )
        button_15.place(
            x=335.0,
            y=158.0,
            width=82.0,
            height=52.0
        )
        #End of auto setup ON 

        #Start of Auto setup - 
        def AutoSetupOff(): 
            ser.write(b'\x02ADZZ;OAS\x03')
            # Send the query
            ser.write(b'\x02QAS\x03')
            time.sleep(0.5) 
            # Wait for the response
            response = ser.read_until(b'\x03')
            # Update the button image based on the response
            if b'0' in response:
                button_image_13.config(file=relative_to_assets("button_24.png"))
                button_image_15.config(file=relative_to_assets("button_18.png"))
                master.state["projectorSettingsAutoSetupOn"] = False  
                master.state["projectorSettingsAutoSetupOff"] = True 
            else:
                button_image_13.config(file=relative_to_assets("button_9.png"))
                master.state["projectorSettingsAutoSetupOff"] = False

        AutoSetupOffFilename = "button_24.png" if master.state.get("projectorSettingsAutoSetupOff") else "button_9.png"
        
        button_image_13 = PhotoImage(
            file=relative_to_assets(AutoSetupOffFilename))
        button_13 = Button(
            image=button_image_13,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: AutoSetupOff(),
            relief="flat"
        )
        button_13.place(
            x=335.0,
            y=231.0,
            width=82.0,
            height=52.0
        )
        #End of auto setup - 

     #Autosetup End 
    ######################

    #Mute Start
    ######################
        #start of mute On 
        def MuteOn(): 
            ser.write(b'\x02ADZZ;AMT:1\x03')
            # Send the query
            ser.write(b'\x02QMT\x03')
            time.sleep(0.5)
            # Wait for the response
            response = ser.read_until(b'\x03')
            # Update the button image based on the response
            if b'1' in response:
                button_image_17.config(file=relative_to_assets("button_23.png"))
                button_image_10.config(file=relative_to_assets("button_11.png"))

                master.state["projectorSettingsMuteOn"] = True
                master.state["projectorSettingsMuteOff"] = False
            else:
                button_image_17.config(file=relative_to_assets("button_12.png"))

                master.state["projectorSettingsMuteOn"] = False

        muteOnFilename = "button_23.png" if master.state.get("projectorSettingsMuteOn") else "button_12.png"

        button_image_17 = PhotoImage(
            file=relative_to_assets(muteOnFilename))
        button_17 = Button(
            image=button_image_17,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: MuteOn(),
            relief="flat"
        )
        button_17.place(
            x=205.0,
            y=365.0,
            width=82.0,
            height=52.0
        )
        #End of Mute On 
    
    #Start of Mute Off
        def MuteOff(): 
            ser.write(b'\x02ADZZ;AMT:0\x03')
            # Send the query
            ser.write(b'\x02QMT\x03')
            time.sleep(0.5) 
            # Wait for the response
            response = ser.read_until(b'\x03')
            # Update the button image based on the response
            if b'0' in response:
                button_image_10.config(file=relative_to_assets("button_24.png"))
                button_image_17.config(file=relative_to_assets("button_18.png"))

                master.state["projectorSettingsMuteOff"] = True
                master.state["projectorSettingsMuteOn"] = False
            else:
                button_image_10.config(file=relative_to_assets("button_9.png"))

                master.state["projectorSettingsMuteOff"] = False

        muteOffFilename = "button_24.png" if master.state.get("projectorSettingsMuteOff") else "button_9.png"

        button_image_10 = PhotoImage(
            file=relative_to_assets(muteOffFilename))
        button_10 = Button(
            image=button_image_10,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: MuteOff(),
            relief="flat"
        )
        button_10.place(
            x=205.0,
            y=450.0,
            width=82.0,
            height=52.0
        )

    #Mute End 
    ######################

    #Power Start  
    ######################

        #Start of Power On 
        def PowerOn(): 
            ser.write(b'\x02ADZZ;PON\x03')
            # Send the query
            ser.write(b'\x02QPW\x03')
            time.sleep(0.5) 
            # Wait for the response
            response = ser.read_until(b'\x03')
            # Update the button image based on the response
            if b'PON' in response:
                button_image_16.config(file=relative_to_assets("button_23.png"))
                button_image_14.config(file=relative_to_assets("button_11.png"))

                master.state["projectorSettingsPowerOn"] = True 
                master.state["projectorSettingsPowerOff"] = False 
            else:
                button_image_16.config(file=relative_to_assets("button_12.png"))
                master.state["projectorSettingsPowerOn"] = False 

        PowerOnFilename = "button_23.png" if master.state.get("projectorSettingsPowerOn") else "button_12.png"

        button_image_16 = PhotoImage(
            file=relative_to_assets(PowerOnFilename))
        button_16 = Button(
            image=button_image_16,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: PowerOn(),
            relief="flat"
        )
        button_16.place(
            x=470.0,
            y=261.0,
            width=82.0,
            height=52.0
        )
        #End of Power On 

        #Start of Power Off
        def PowerOff(): 
            ser.write(b'\x02ADZZ;POF\x03')
            # Send the query
            ser.write(b'\x02QPW\x03')
            time.sleep(0.5) 
            # Wait for the response
            response = ser.read_until(b'\x03')
            # Update the button image based on the response
            if b'POF' in response:
                button_image_14.config(file=relative_to_assets("button_24.png"))
                button_image_16.config(file=relative_to_assets("button_18.png"))
                master.state["projectorSettingsPowerOn"] = False 
                master.state["projectorSettingsPowerOff"] = True 
            else:
                button_image_14.config(file=relative_to_assets("button_9.png"))
                master.state["projectorSettingsPowerOff"] = False

        PowerOffFilename = "button_24.png" if master.state.get("projectorSettingsPowerOff") else "button_9.png"        

        button_image_14 = PhotoImage(
            file=relative_to_assets(PowerOffFilename))
        button_14 = Button(
            image=button_image_14,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: PowerOff(),
            relief="flat"
        )
        button_14.place(
            x=470.0,
            y=344.0,
            width=82.0,
            height=52.0
        )
        #End of Power Off 

    #Power End 
    ######################

        #start of Zoom + 
        def ZoomPlus(): 
            ser.write(b'\x02ADZZ;DZU\x03')

        button_image_19 = PhotoImage(
            file=relative_to_assets("button_19.png"))
        button_19 = Button(
            image=button_image_19,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: ZoomPlus(),
            relief="flat"
        )
        button_19.place(
            x=77.0,
            y=138.0,
            width=76.0,
            height=65.0
        )
        #End of zoom + 
        #Start of Zoom - 
        def ZoomMinus(): 
            ser.write(b'\x02ADZZ;DZD\x03')
        
        button_image_20 = PhotoImage(
            file=relative_to_assets("button_20.png"))
        button_20 = Button(
            image=button_image_20,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: ZoomMinus(),
            relief="flat"
        )
        button_20.place(
            x=83.0,
            y=229.0,
            width=65.0,
            height=54.0
        )
        #End of Zoom - 
        #start of Volume up 
        def VolumeUp(): 
            ser.write(b'\x02ADZZ;AUU\x03')
        button_image_21 = PhotoImage(
            file=relative_to_assets("button_21.png"))
        button_21 = Button(
            image=button_image_21,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: VolumeUp(),
            relief="flat"
        )
        button_21.place(
            x=211.0,
            y=141.0,
            width=75.0,
            height=59.0
        )
        #End of volume up 

        #Start of volume down 
        def VolumeDown(): 
            ser.write(b'\x02ADZZ;AUD\x03')
        button_image_22 = PhotoImage(
            file=relative_to_assets("button_22.png"))
        button_22 = Button(
            image=button_image_22,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: VolumeDown(),
            relief="flat"
        )
        button_22.place(
            x=216.0,
            y=230.0,
            width=60.0,
            height=50.0
        )
        #End of volume down        
        master.mainloop()

