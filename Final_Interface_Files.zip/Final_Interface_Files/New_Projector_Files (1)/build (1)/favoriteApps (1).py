from pathlib import Path
from tkinter import Canvas, Button, PhotoImage, Frame

import webbrowser
import os
import subprocess

OUTPUT_PATH = Path(__file__).parent
ASSETS_PATH = OUTPUT_PATH / Path(r"/home/cms/Documents/Projector_Files/New_Projector_Files/build/assets/favApps")

def relative_to_assets(path: str) -> Path:
    return ASSETS_PATH / Path(path)

class FavoriteApps(Frame):
    def __init__(self, master, *args, **kwargs):
        Frame.__init__(self, master, *args, **kwargs)
        master.geometry("1023x604")
        master.configure(bg = "#F2F2EB")
        master.resizable(False, False)

        canvas = Canvas(
            master,
            bg = "#F2F2EB",
            height = 604,
            width = 1023,
            bd = 0,
            highlightthickness = 0,
            relief = "ridge"
        )

        canvas.place(x = 0, y = 0)

        ### LINK TO POWERPOINT
       #def openPowerPoint():
                
            #else:
                #print("PowerPoint is not installed on this system.")

        button_image_1 = PhotoImage(
            file=relative_to_assets("button_1.png"))
        button_1 = Button(
            image=button_image_1,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: subprocess.Popen(['libreoffice', '--impress']),
            relief="flat"
        )
        button_1.place(
            x=43.0,
            y=325.0,
            width=284.0,
            height=234.0
        )
        ### END LINK TO POWERPOINT

        ### LINK TO GOOGLE SLIDES 
        url_slides = "https://accounts.google.com/v3/signin/identifier?dsh=S2131685600%3A1677550187917585&continue=https%3A%2F%2Fdocs.google.com%2Fpresentation%2Fu%2F0%2F&followup=https%3A%2F%2Fdocs.google.com%2Fpresentation%2Fu%2F0%2F&ltmpl=slides&passive=1209600&service=wise&flowName=GlifWebSignIn&flowEntry=ServiceLogin&ifkv=AWnogHe3ZgZg0GhXrq9GzqIuVSSuPn9zrrYj-hZlHdRx-i47ZWJouBVrWtMfBQYyX1Nw9onKgdgfXQ"
        button_image_2 = PhotoImage(
            file=relative_to_assets("button_2.png"))
        button_2 = Button(
            image=button_image_2,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: webbrowser.open(url_slides),
            relief="flat"
        )
        button_2.place(
            x=369.0,
            y=325.0,
            width=284.0,
            height=234.0
        )
         ### END LINK TO GOOGLE SLIDES 

        ### NAV TO MAINMENU
        button_image_3 = PhotoImage(
            file=relative_to_assets("button_3.png"))
        button_3 = Button(
            image=button_image_3,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: master.redirect_page("PAGE_MAIN_MENU"),
            relief="flat"
        )
        button_3.place(
            x=695.0,
            y=325.0,
            width=284.0,
            height=234.0
        )
         ### END NAV TO MAINMENU

        ##LINK TO GOOGLE DRIVE
        url_drive = "https://accounts.google.com/v3/signin/identifier?dsh=S419511241%3A1677550082886042&continue=http%3A%2F%2Fdrive.google.com%2F%3Futm_source%3Den&ltmpl=drive&passive=true&service=wise&usp=gtd&utm_campaign=web&utm_content=gotodrive&utm_medium=button&flowName=GlifWebSignIn&flowEntry=ServiceLogin&ifkv=AWnogHeY-SkcWUsWqRf3_vmY9jXW_wt7jBxRkHWzS3fcyFuDst9YD201pLpj95AvO87ABY8s1PRY5g"
        button_image_4 = PhotoImage(
            file=relative_to_assets("button_4.png"))
        button_4 = Button(
            image=button_image_4,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: webbrowser.open(url_drive),
            relief="flat"
        )
        button_4.place(
            x=369.0,
            y=80.0,
            width=284.0,
            height=234.0
        )
        #END TO GOOGLE DRIVE

        ### LINK TO GOOGLE
        url_google = "https://google.com"
        button_image_5 = PhotoImage(
            file=relative_to_assets("button_5.png"))
        button_5 = Button(
            image=button_image_5,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: webbrowser.open(url_google),
            relief="flat"
        )
        button_5.place(
            x=43.0,
            y=80.0,
            width=284.0,
            height=234.0
        )
        ### END LINK TO GOOGLE

        image_image_1 = PhotoImage(
            file=relative_to_assets("image_1.png"))
        image_1 = canvas.create_image(
            511.0,
            36.0,
            image=image_image_1
        )

        ###LINK TO YOUTUBE 
        url_youtube = "https://youtube.com"
        button_image_6 = PhotoImage(
        file=relative_to_assets("button_6.png"))
        button_6 = Button(
        image=button_image_6,
        borderwidth=0,
        highlightthickness=0,
        command=lambda: webbrowser.open(url_youtube),
        relief="flat"
        )       
        button_6.place(
        x=693.0,
        y=80.0,
        width=284.0,
        height=234.0
        )
         ###END LINK TO YOUTUBE 
        
        master.mainloop()
