from pathlib import Path
import serial 
import time
from tkinter import Canvas, Button, PhotoImage, Frame

OUTPUT_PATH = Path(__file__).parent
ASSETS_PATH = OUTPUT_PATH / Path(r"/home/cms/Documents/Projector_Files/New_Projector_Files/build/assets/projInputs")
# set up the serial connection
ser = serial.Serial('/dev/ttyUSB0', 9600)

def relative_to_assets(path: str) -> Path:
    return ASSETS_PATH / Path(path)

class ProjectorInputs(Frame):
    def __init__(self, master, *args, **kwargs):
        Frame.__init__(self, master, *args, **kwargs)
        master.geometry("1023x604")
        master.configure(bg = "#F2F2EB")
        master.resizable(False, False)

        canvas = Canvas(
        master,
        bg = "#F2F2EB",
        height = 604,
        width = 1023,
        bd = 0,
        highlightthickness = 0,
        relief = "ridge"
    )

        canvas.place(x = 0, y = 0)
        image_image_1 = PhotoImage(
            file=relative_to_assets("image_1.png"))
        image_1 = canvas.create_image(
            511.0,
            36.0,
            image=image_image_1
        )
        #Start of HDMI 2 
        def HDMI2(): 
            ser.write(b'\x02ADZZ;IIS:HD2\x03')
            # Send the query
            ser.write(b'\x02QIN\x03')
            time.sleep(0.5) 
            # Wait for the response
            response = ser.read_until(b'\x03')
            # Update the button image based on the response
            if b'HD2' in response:
                button_image_1.config(file=relative_to_assets("button_1_ON.png"))
                button_image_2.config(file=relative_to_assets("button_2.png"))
                button_image_3.config(file=relative_to_assets("button_3.png"))
                button_image_4.config(file=relative_to_assets("button_4.png"))
                button_image_5.config(file=relative_to_assets("button_5.png"))

                master.state["projectInputsHDMI1"] = False
                master.state["projectInputsHDMI2"] = True 
                master.state["projectInputsVGA1"] = False
                master.state["projectInputsVGA2"] = False
                master.state["projectInputsVideoIn"] = False
            else:
                button_image_1.config(file=relative_to_assets("button_1.png"))
                master.state["projectInputsHDMI2"] = False 

        HDMI2Filename = "button_1_ON.png" if master.state.get("projectInputsHDMI2") else "button_1.png"

        button_image_1 = PhotoImage(
            file=relative_to_assets(HDMI2Filename))
        button_1 = Button(
            image=button_image_1,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: HDMI2(),
            relief="flat"
        )
        button_1.place(
            x=370.0,
            y=325.0,
            width=284.0,
            height=234.0
        )
        #End of HDMI 2 
        #Start of HDMI 1 
        def HDMI1(): 
            ser.write(b'\x02ADZZ;IIS:HD1\x03')
            # Send the query
            ser.write(b'\x02QIN\x03')
            time.sleep(0.5) 
            # Wait for the response
            response = ser.read_until(b'\x03')
            # Update the button image based on the response
            if b'HD1' in response:
                button_image_1.config(file=relative_to_assets("button_1.png"))
                button_image_2.config(file=relative_to_assets("button_2_ON.png"))
                button_image_3.config(file=relative_to_assets("button_3.png"))
                button_image_4.config(file=relative_to_assets("button_4.png"))
                button_image_5.config(file=relative_to_assets("button_5.png"))

                master.state["projectInputsHDMI1"] = True
                master.state["projectInputsHDMI2"] = False
                master.state["projectInputsVGA1"] = False
                master.state["projectInputsVGA2"] = False
                master.state["projectInputsVideoIn"] = False
            else:
                button_image_2.config(file=relative_to_assets("button_2.png"))
                master.state["projectInputsHDMI1"] = False

        HDMI1Filename = "button_2_ON.png" if master.state.get("projectInputsHDMI1") else "button_2.png"

        button_image_2 = PhotoImage(
            file=relative_to_assets(HDMI1Filename))
        button_2 = Button(
            image=button_image_2,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: HDMI1(),
            relief="flat"
        )
        button_2.place(
            x=43.0,
            y=325.0,
            width=284.0,
            height=234.0
        )
        #End of HDMI 1 
        #Start of VGA 1 
        def VGA1(): 
            ser.write(b'\x02ADZZ;IIS:RG1\x03')
            # Send the query
            ser.write(b'\x02QIN\x03')
            time.sleep(0.5) 
            # Wait for the response
            response = ser.read_until(b'\x03')
            # Update the button image based on the response
            if b'RG1' in response:
                button_image_1.config(file=relative_to_assets("button_1.png"))
                button_image_2.config(file=relative_to_assets("button_2.png"))
                button_image_3.config(file=relative_to_assets("button_3_ON.png"))
                button_image_4.config(file=relative_to_assets("button_4.png"))
                button_image_5.config(file=relative_to_assets("button_5.png"))

                master.state["projectInputsHDMI1"] = False
                master.state["projectInputsHDMI2"] = False
                master.state["projectInputsVGA1"] = True
                master.state["projectInputsVGA2"] = False
                master.state["projectInputsVideoIn"] = False
            else:
                button_image_3.config(file=relative_to_assets("button_3.png"))
                master.state["projectInputsVGA1"] = False
        
        VGA1Filename = "button_3_ON.png" if master.state.get("projectInputsVGA1") else "button_3.png"

        button_image_3 = PhotoImage(
            file=relative_to_assets(VGA1Filename))
        button_3 = Button(
            image=button_image_3,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: VGA1(),
            relief="flat"
        )
        button_3.place(
            x=369.0,
            y=82.0,
            width=284.0,
            height=234.0
        )
        #End of VGA 1 
        #Start of VGA 2 
        def VGA2(): 
            ser.write(b'\x02ADZZ;IIS:RG2\x03')
            # Send the query
            ser.write(b'\x02QIN\x03')
            time.sleep(0.5) 
            # Wait for the response
            response = ser.read_until(b'\x03')
            # Update the button image based on the response
            if b'RG2' in response:
                button_image_1.config(file=relative_to_assets("button_1.png"))
                button_image_2.config(file=relative_to_assets("button_2.png"))
                button_image_3.config(file=relative_to_assets("button_3.png"))
                button_image_4.config(file=relative_to_assets("button_4_ON.png"))
                button_image_5.config(file=relative_to_assets("button_5.png"))

                master.state["projectInputsHDMI1"] = False
                master.state["projectInputsHDMI2"] = False 
                master.state["projectInputsVGA1"] = False
                master.state["projectInputsVGA2"] = True
                master.state["projectInputsVideoIn"] = False
            else:
                button_image_4.config(file=relative_to_assets("button_4.png"))
                master.state["projectInputsVGA2"] = False

        VGA2Filename = "button_4_ON.png" if master.state.get("projectInputsVGA2") else "button_4.png"

        button_image_4 = PhotoImage(
            file=relative_to_assets(VGA2Filename))
        button_4 = Button(
            image=button_image_4,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: VGA2(),
            relief="flat"
        )
        button_4.place(
            x=695.0,
            y=82.0,
            width=284.0,
            height=234.0
        )
        #End of VGA 2 
        #Start of video in button 
        def VideoInButton(): 
            ser.write(b'\x02ADZZ;IIS:VID\x03')
            # Send the query
            ser.write(b'\x02QIN\x03')
            time.sleep(0.5) 
            # Wait for the response
            response = ser.read_until(b'\x03')
            # Update the button image based on the response
            if b'VID' in response:
                button_image_1.config(file=relative_to_assets("button_1.png"))
                button_image_2.config(file=relative_to_assets("button_2.png"))
                button_image_3.config(file=relative_to_assets("button_3.png"))
                button_image_4.config(file=relative_to_assets("button_4.png"))
                button_image_5.config(file=relative_to_assets("button_5_ON.png"))

                master.state["projectInputsHDMI1"] = False
                master.state["projectInputsHDMI2"] = False 
                master.state["projectInputsVGA1"] = False
                master.state["projectInputsVGA2"] = False
                master.state["projectInputsVideoIn"] = True

            else:
                button_image_5.config(file=relative_to_assets("button_5.png"))
                master.state["projectInputsVideoIn"] = False 

        VideoInFilename = "button_5_ON.png" if master.state.get("projectInputsVideoIn") else "button_5.png"
        
        button_image_5 = PhotoImage(
            file=relative_to_assets(VideoInFilename))
        button_5 = Button(
            image=button_image_5,
            borderwidth=0,
            highlightthickness=0,
            command=lambda: VideoInButton(),
            relief="flat"
        )
        button_5.place(
            x=43.0,
            y=82.0,
            width=284.0,
            height=234.0
        )
        #End of video in button 

        button_image_6 = PhotoImage(
            file=relative_to_assets("button_6.png"))
        button_6 = Button(
            image=button_image_6,
            borderwidth=0,
            highlightthickness=0,
           command=lambda: master.redirect_page("PAGE_MAIN_MENU"),
            relief="flat"
        )
        button_6.place(
            x=695.0,
            y=325.0,
            width=284.0,
            height=234.0
        )
                
        master.mainloop()
