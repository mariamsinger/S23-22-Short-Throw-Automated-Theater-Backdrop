from pathlib import Path
from tkinter import Canvas, Button, PhotoImage, Frame

import subprocess
import os
import webbrowser 

OUTPUT_PATH = Path(__file__).parent
ASSETS_PATH = OUTPUT_PATH / Path(r"/home/cms/Documents/Projector_Files/New_Projector_Files/build/assets/animBackdrop")

def relative_to_assets(path: str) -> Path:
    return ASSETS_PATH / Path(path)

class AnimateBackdrop(Frame):
    def __init__(self, master, *args, **kwargs):
        Frame.__init__(self, master, *args, **kwargs)
        master.geometry("1023x604")
        master.configure(bg = "#F2F2EB")
        master.resizable(False, False)

        canvas = Canvas(
            master,
            bg = "#F2F2EB",
            height = 604,
            width = 1023,
            bd = 0,
            highlightthickness = 0,
            relief = "ridge"
        )

        canvas.place(x = 0, y = 0)
        image_image_1 = PhotoImage(
            file=relative_to_assets("image_1.png"))
        image_1 = canvas.create_image(
            511.0,
            38.0,
            image=image_image_1
        )

        ##NAV TO MAIN MENU
        button_image_1 = PhotoImage(
        file=relative_to_assets("button_1.png"))
        button_1 = Button(
        image=button_image_1,
        borderwidth=0,
        highlightthickness=0,
        command=lambda: master.redirect_page("PAGE_MAIN_MENU"),
        relief="flat"
        )
        button_1.place(
        x=693.0,
        y=178.0,
        width=302.20513916015625,
        height=249.0
        )
        ##END NAV TO MAIN MENU


        ###LINK TO ANIMATING 
        url_animate = "https://scratch.mit.edu/"
        button_image_2 = PhotoImage(
        file=relative_to_assets("button_2.png"))
        button_2 = Button(
        image=button_image_2,
        borderwidth=0,
        highlightthickness=0,
        command=lambda: webbrowser.open(url_animate),
        relief="flat"
        )
        button_2.place(
        x=36.0,
        y=178.0,
        width=302.20513916015625,
        height=249.0
        )
         ###END LINK TO ANIMATING 

        #NAV TO SAVED FILES 
        def openSavedFiles(): 
            folder_path = "/home/cms/Desktop/Saved_Designs" # Replace with the path of the folder you want to open

            if os.path.exists(folder_path):
                subprocess.call(["open", folder_path])  # macOS
                # subprocess.call(["xdg-open", folder_path])  # linux
                # subprocess.Popen('explorer "' + folder_path + '"') #Windows
            else:
                 print("Folder does not exist.")


        button_image_3 = PhotoImage(
        file=relative_to_assets("button_3.png"))
        button_3 = Button(
        image=button_image_3,
        borderwidth=0,
        highlightthickness=0,
        command=lambda:openSavedFiles(),
        relief="flat"
        )
        button_3.place(
        x=366.0,
        y=178.0,
        width=302.20513916015625,
        height=249.0
        )

        #END OF NAV TO FAV FILES 
        
        master.mainloop()
